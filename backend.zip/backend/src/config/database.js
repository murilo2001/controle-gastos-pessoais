module.exports = {
    host: 'localhost',
    username: 'root',
    password: 'c10437be',
    database: 'teste',
    dialect: 'mysql',
    define: {
      timestamps: true,
      underscored: true,
      underscoredAll: true
    },
  }; 