'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {

    //await queryInterface.removeColumn('usuarios', 'is_logged',);
  },

  down: async (queryInterface, Sequelize) => {

  }
};
